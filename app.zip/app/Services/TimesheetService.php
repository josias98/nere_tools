<?php

namespace App\Services;

use App\Models\Employee;
use App\Models\TimesheetGeneration;
use App\Models\TimesheetGenerationFile;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use ZipArchive;

class TimesheetService
{
    /**
     * @param  array<string, mixed>  $data
     */
    public function generate(array $data, User $user): TimesheetGeneration
    {
        $employees = Employee::query()
            ->whereIn('id', $data['employee_ids'])
            ->where('is_active', true)
            ->orderBy('display_name')
            ->get();

        if ($employees->isEmpty()) {
            throw new RuntimeException('Veuillez selectionner au moins un collaborateur actif.');
        }

        $year = (int) $data['year'];
        $startMonth = (int) $data['start_month'];
        $endMonth = (int) $data['end_month'];

        $generation = TimesheetGeneration::query()->create([
            'uuid' => (string) Str::uuid(),
            'period_start' => Carbon::create($year, $startMonth, 1),
            'period_end' => Carbon::create($year, $endMonth, 1)->endOfMonth(),
            'year' => $year,
            'period_label' => $this->periodLabel($year, $startMonth, $endMonth),
            'generated_by_user_id' => $user->id,
            'employee_count' => $employees->count(),
            'pdf_count' => 0,
            'status' => 'completed',
        ]);

        foreach (range($startMonth, $endMonth) as $month) {
            foreach ($employees as $employee) {
                $this->createFile($generation, $employee, $year, $month);
            }
        }

        $generation->update([
            'pdf_count' => $generation->files()->count(),
            'zip_path' => $this->zip($generation),
        ]);

        return $generation->refresh();
    }

    /**
     * @return array<int, array{label: string, start: Carbon, end: Carbon}>
     */
    public function weeks(int $year, int $month): array
    {
        $cursor = Carbon::create($year, $month, 1);
        $end = $cursor->copy()->endOfMonth();
        $weeks = [];

        while ($cursor->lte($end)) {
            $weekEnd = $cursor->copy()->next(Carbon::SUNDAY);
            if ($weekEnd->gt($end) || $cursor->isSunday()) {
                $weekEnd = $cursor->isSunday() ? $cursor->copy() : $end->copy();
            }

            $weeks[] = [
                'label' => 'Semaine '.(count($weeks) + 1),
                'start' => $cursor->copy(),
                'end' => $weekEnd->copy(),
            ];

            $cursor = $weekEnd->copy()->addDay();
        }

        return $weeks;
    }

    public function signatureDate(int $year, int $month): Carbon
    {
        $date = Carbon::create($year, $month, 1)->endOfMonth()->addDay();

        while ($date->isWeekend()) {
            $date->addDay();
        }

        return $date;
    }

    /**
     * @return array<int, array{label: string, value: float}>
     */
    public function columns(Employee $employee): array
    {
        $columns = [
            ['label' => 'IPAS', 'value' => $employee->ipas_rate],
            ['label' => 'CATAL1,5T', 'value' => $employee->catal_rate],
            ['label' => 'IPDE', 'value' => $employee->ipde_rate],
        ];

        if ($employee->requires_other_projects) {
            $columns[] = ['label' => 'Autres projets', 'value' => 100 - array_sum(array_column($columns, 'value'))];
        }

        $total = array_sum(array_column($columns, 'value'));
        if (abs($total - 100) > 0.01) {
            throw new RuntimeException("Le total analytique de {$employee->name()} doit etre egal a 100%.");
        }

        return $columns;
    }

    private function createFile(TimesheetGeneration $generation, Employee $employee, int $year, int $month): TimesheetGenerationFile
    {
        $safeName = Str::of($employee->name())->ascii()->replaceMatches('/[^A-Za-z0-9]+/', '_')->trim('_');
        $fileName = sprintf('Feuille_de_temps_%d_%02d_%s.pdf', $year, $month, $safeName);
        $path = sprintf('timesheets/%d/%02d/%s/%s', $year, $month, $safeName, $fileName);

        Storage::disk('local')->put($path, $this->pdf($employee, $year, $month));

        return $generation->files()->create([
            'employee_id' => $employee->id,
            'month' => $month,
            'year' => $year,
            'file_name' => $fileName,
            'file_path' => $path,
            'status' => 'generated',
        ]);
    }

    private function zip(TimesheetGeneration $generation): string
    {
        $zipPath = "timesheets/zips/{$generation->uuid}.zip";
        Storage::disk('local')->makeDirectory('timesheets/zips');

        $zip = new ZipArchive;
        $absolutePath = Storage::disk('local')->path($zipPath);

        if ($zip->open($absolutePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Impossible de creer le fichier ZIP.');
        }

        foreach ($generation->files as $file) {
            $zip->addFile(Storage::disk('local')->path($file->file_path), $file->file_name);
        }

        $zip->close();

        return $zipPath;
    }

    private function pdf(Employee $employee, int $year, int $month): string
    {
        $lines = [
            'FEUILLE DE TEMPS',
            $employee->entity,
            'Collaborateur: '.$employee->name(),
            'Lieu: '.$employee->location,
            'Poste: '.$employee->job_title,
            'Code analytique: '.$employee->analytic_code,
            'Mois: '.Carbon::create($year, $month, 1)->translatedFormat('F Y'),
            '',
            'Repartition hebdomadaire',
        ];

        foreach ($this->weeks($year, $month) as $week) {
            $lines[] = $week['label'].' : '.$week['start']->format('d/m/Y').' - '.$week['end']->format('d/m/Y');
        }

        $lines[] = '';
        foreach ($this->columns($employee) as $column) {
            $lines[] = $column['label'].' : '.$column['value'].'%';
        }

        $lines[] = '';
        $lines[] = 'Date de signature: '.$this->signatureDate($year, $month)->format('d/m/Y');
        $lines[] = 'Signature du salarie: '.$employee->name();
        $lines[] = ($employee->signature_title ?: 'Signature du responsable hierarchique').': '.$employee->signatory_name;

        return $this->simplePdf($lines);
    }

    /**
     * ponytail: tiny text PDF; switch to DomPDF when exact layout matters.
     *
     * @param  array<int, string>  $lines
     */
    private function simplePdf(array $lines): string
    {
        $content = "BT\n/F1 12 Tf\n50 790 Td\n";
        foreach ($lines as $line) {
            $content .= '('.$this->pdfText($line).") Tj\n0 -18 Td\n";
        }
        $content .= "ET\n";

        $objects = [
            "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n",
            "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n",
            "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj\n",
            "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n",
            '5 0 obj << /Length '.strlen($content)." >> stream\n{$content}endstream\nendobj\n",
        ];

        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objects as $object) {
            $offsets[] = strlen($pdf);
            $pdf .= $object;
        }

        $xref = strlen($pdf);
        $pdf .= "xref\n0 6\n0000000000 65535 f \n";
        for ($i = 1; $i <= 5; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        return $pdf."trailer << /Size 6 /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";
    }

    private function pdfText(string $text): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], Str::ascii($text));
    }

    private function periodLabel(int $year, int $startMonth, int $endMonth): string
    {
        if ($startMonth === 1 && $endMonth === 6) {
            return "S1 {$year}";
        }

        if ($startMonth === 7 && $endMonth === 12) {
            return "S2 {$year}";
        }

        return sprintf('%d_%02d_%02d', $year, $startMonth, $endMonth);
    }
}
