<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? config('app.name', 'Nere Tools')); ?></title>
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
</head>
<body>
    <div class="nc-shell">
        <?php if(auth()->guard()->check()): ?>
            <header class="nc-header">
                <div class="nc-header-inner">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nc-brand" aria-label="Nere Tools - Accueil">
                        <img class="nc-logo" src="<?php echo e(asset('brand/nere-capital-rgb.png')); ?>" alt="Nere Capital">
                        <span class="nc-muted">Portail interne</span>
                    </a>

                    <nav class="nc-nav" aria-label="Navigation principale">
                        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        <a href="<?php echo e(route('timesheets.index')); ?>">Feuilles de temps</a>
                        <?php if(auth()->user()->role === \App\Models\User::ROLE_ADMIN): ?>
                            <a href="<?php echo e(route('admin.index')); ?>">Administration</a>
                        <?php endif; ?>
                    </nav>

                    <div class="nc-nav">
                        <div class="nc-user">
                            <strong><?php echo e(auth()->user()->name); ?></strong>
                            <span class="nc-muted"><?php echo e(auth()->user()->email); ?></span>
                        </div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="nc-ghost">Deconnexion</button>
                        </form>
                    </div>
                </div>
            </header>
        <?php endif; ?>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <div class="nc-footer-bar" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></div>
</body>
</html>
<?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/layouts/app.blade.php ENDPATH**/ ?>