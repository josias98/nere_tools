<?php $__env->startSection('content'); ?>
    <section class="nc-page">
        <div class="nc-title-row">
            <div>
                <p class="nc-kicker">Module finance</p>
                <h1 class="nc-title">Feuilles de temps</h1>
                <p class="nc-lead">La date de signature correspond au premier jour ouvre suivant la fin du mois.</p>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <p class="nc-alert"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>

        <div class="nc-grid two">
            <section class="nc-panel">
                <h2>Generation</h2>
                <form method="POST" action="<?php echo e(route('timesheets.generate')); ?>" class="nc-form-grid">
                    <?php echo csrf_field(); ?>
                    <div class="nc-field">
                        <label for="period_type">Type de periode</label>
                        <select id="period_type" name="period_type">
                            <option value="month">Mois</option>
                            <option value="quarter">Trimestre</option>
                            <option value="semester" selected>Semestre</option>
                            <option value="custom">Personnalisee</option>
                        </select>
                    </div>
                    <div class="nc-field">
                        <label for="year">Annee</label>
                        <input id="year" name="year" type="number" min="2020" max="2100" value="<?php echo e(old('year', now()->year)); ?>">
                    </div>
                    <div class="nc-field">
                        <label for="start_month">Mois de debut</label>
                        <input id="start_month" name="start_month" type="number" min="1" max="12" value="<?php echo e(old('start_month', 1)); ?>">
                    </div>
                    <div class="nc-field">
                        <label for="end_month">Mois de fin</label>
                        <input id="end_month" name="end_month" type="number" min="1" max="12" value="<?php echo e(old('end_month', 6)); ?>">
                    </div>
                    <div class="nc-field" style="grid-column: 1 / -1">
                        <label for="employee_ids">Collaborateurs</label>
                        <select id="employee_ids" name="employee_ids[]" multiple size="6" required>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name()); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="nc-actions">
                        <button class="nc-button is-secondary" type="submit">Generer les feuilles</button>
                        <a class="nc-ghost" href="<?php echo e(route('timesheets.index')); ?>">Reinitialiser</a>
                    </div>
                </form>
            </section>

            <aside class="nc-panel">
                <h2>Regles appliquees</h2>
                <table class="nc-table">
                    <tbody>
                        <tr><th scope="row">IPAS</th><td>Conserve dans la repartition.</td></tr>
                        <tr><th scope="row">Autres projets</th><td>Ajoute pour Job et Germaine.</td></tr>
                        <tr><th scope="row">Signature</th><td>Cas particuliers appliques depuis la base.</td></tr>
                    </tbody>
                </table>
                <div class="nc-actions">
                    <a class="nc-ghost" href="<?php echo e(route('timesheets.history')); ?>">Voir l'historique</a>
                </div>
            </aside>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Feuilles de temps - Nere Tools'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/timesheets/index.blade.php ENDPATH**/ ?>