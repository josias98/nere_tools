<?php $__env->startSection('content'); ?>
    <section class="nc-page">
        <div class="nc-title-row">
            <div>
                <p class="nc-kicker">Portail interne</p>
                <h1 class="nc-title">Nere Tools</h1>
                <p class="nc-lead">Bienvenue, <?php echo e(auth()->user()->name); ?>. Selectionnez un outil interne pour demarrer.</p>
            </div>
        </div>

        <div class="nc-grid tools">
            <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $roles = $accessibleRoutes[$tool->route] ?? [];
                    $isActive = $tool->status === \App\Models\Tool::STATUS_ACTIVE;
                    $hasAccess = empty($roles) || auth()->user()->hasAnyRole($roles);
                ?>

                <article class="nc-card">
                    <div class="nc-card-top">
                        <div>
                            <h2><?php echo e($tool->name); ?></h2>
                            <p><?php echo e($tool->description); ?></p>
                        </div>
                        <span class="nc-badge <?php echo e($isActive ? 'active' : ''); ?>"><?php echo e($isActive ? 'Actif' : 'Bientot'); ?></span>
                    </div>

                    <div class="nc-actions">
                        <?php if($isActive && $hasAccess): ?>
                            <a href="<?php echo e($tool->route); ?>" class="nc-button is-secondary">Acceder</a>
                        <?php elseif($isActive): ?>
                            <span class="nc-ghost" aria-disabled="true">Non autorise</span>
                        <?php else: ?>
                            <span class="nc-ghost" aria-disabled="true">Bientot disponible</span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Nere Tools'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/dashboard.blade.php ENDPATH**/ ?>