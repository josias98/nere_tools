<?php $__env->startSection('content'); ?>
    <section class="nc-auth">
        <div class="nc-auth-inner">
            <div class="nc-auth-card">
                <img class="nc-logo" src="<?php echo e(asset('brand/nere-capital-rgb.png')); ?>" alt="Nere Capital">
                <span class="nc-badge warning">Acces refuse</span>
                <h1 class="nc-title">Compte non autorise</h1>
                <p class="nc-lead"><?php echo e($reason); ?></p>

                <?php if($email): ?>
                    <p class="nc-alert">Compte Microsoft detecte : <strong><?php echo e($email); ?></strong></p>
                <?php endif; ?>

                <div class="nc-actions">
                    <a href="<?php echo e(route('login')); ?>" class="nc-button">Retour a la connexion</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Acces refuse - Nere Tools'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/auth/denied.blade.php ENDPATH**/ ?>