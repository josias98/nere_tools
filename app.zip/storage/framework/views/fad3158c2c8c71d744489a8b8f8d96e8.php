<?php $__env->startSection('content'); ?>
    <section class="nc-auth">
        <div class="nc-auth-inner">
            <div class="nc-auth-card">
                <img class="nc-logo" src="<?php echo e(asset('brand/nere-capital-rgb.png')); ?>" alt="Nere Capital">
                <div class="nc-title-row">
                    <div>
                        <p class="nc-kicker">Connexion securisee</p>
                        <h1 class="nc-title">Nere Tools</h1>
                        <p class="nc-lead">Connectez-vous avec votre compte Microsoft 365 professionnel pour acceder au portail interne.</p>
                    </div>
                </div>

                <?php if($errors->has('microsoft')): ?>
                    <p class="nc-alert"><?php echo e($errors->first('microsoft')); ?></p>
                <?php endif; ?>

                <div class="nc-actions">
                    <a href="<?php echo e(route('auth.microsoft.redirect')); ?>" class="nc-button">Continuer avec Microsoft 365</a>
                </div>
                <p class="nc-muted">Acces reserve aux collaborateurs autorises.</p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Connexion - Nere Tools'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/auth/login.blade.php ENDPATH**/ ?>