<?php $__env->startSection('content'); ?>
    <section class="nc-page">
        <div class="nc-title-row">
            <div>
                <p class="nc-kicker">Generation terminee</p>
                <h1 class="nc-title"><?php echo e($generation->period_label); ?></h1>
                <p class="nc-lead"><?php echo e($generation->pdf_count); ?> PDF pour <?php echo e($generation->employee_count); ?> collaborateur(s), genere par <?php echo e($generation->user->name); ?>.</p>
            </div>
        </div>

        <div class="nc-actions">
            <a class="nc-button is-secondary" href="<?php echo e(route('timesheets.download.zip', $generation)); ?>">Telecharger le ZIP</a>
            <a class="nc-ghost" href="<?php echo e(route('timesheets.index')); ?>">Nouvelle generation</a>
        </div>

        <section class="nc-panel" style="margin-top: 20px">
            <h2>Fichiers individuels</h2>
            <table class="nc-table">
                <thead>
                    <tr><th>Collaborateur</th><th>Mois</th><th>Fichier</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $generation->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($file->employee->name()); ?></td>
                            <td><?php echo e(str_pad((string) $file->month, 2, '0', STR_PAD_LEFT)); ?>/<?php echo e($file->year); ?></td>
                            <td><?php echo e($file->file_name); ?></td>
                            <td><a class="nc-ghost" href="<?php echo e(route('timesheets.download.file', $file)); ?>">Telecharger</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Resultat - Feuilles de temps'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\JosiasMansourDIAMITA\Documents\Projects\NERE Capital\Tools\resources\views/timesheets/result.blade.php ENDPATH**/ ?>